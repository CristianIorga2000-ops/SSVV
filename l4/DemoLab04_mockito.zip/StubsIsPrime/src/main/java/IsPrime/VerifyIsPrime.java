package IsPrime;


public class VerifyIsPrime {

    public VerifyIsPrime()
    {
        System.out.println("Verify is prime...");

    }

    public boolean isPrime(int n) throws MyValueException{

        /*
        boolean b = true;
        if(n<0)
        {
            throw new MyValueException("data not valid");
        }
        if(n<2)
        {
            b=false;
        }
        else
        {
            int i=2;
            while (b && (i<= (n/2)))
            {
                if ((n % i) == 0)
                {
                    b=false;
                }
                i++;
            }
        }
        return b;
         */
        return true;
    }


}
